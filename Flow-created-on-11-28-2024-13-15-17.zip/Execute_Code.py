from promptflow import tool
import io
import contextlib
import pandas as pd
from azure.storage.blob import BlobServiceClient
from datetime import datetime

@tool
def my_python_tool(input1: str) -> str:
    """
    This tool retrieves all tabular files (Excel and CSV) from Azure Blob Storage in a specified directory, 
    loads them into a dictionary of pandas DataFrames, and executes the Python code passed as a string 
    in `input1` with access to all these DataFrames.
    It also intercepts calls to pd.read_excel() and pd.read_csv() in the input code to use the 
    preloaded DataFrames from Azure Blob Storage.
    """

    
    try:
        # Azure Blob storage details
        account_url = "https://cxqaazureaihub8779474245.blob.core.windows.net"
        sas_token = "sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2030-11-21T02:02:26Z&st=2024-11-20T18:02:26Z&spr=https&sig=YfZEUMeqiuBiG7le2JfaaZf%2FW6t8ZW75yCsFM6nUmUw%3D"
        container_name = "5d74a98c-1fc6-4567-8545-2632b489bd0b-azureml-blobstore"
        target_folder_path = "UI/2024-11-20_142337_UTC/cxqa_data/tabular/"

        # Initialize the BlobServiceClient with the SAS token
        blob_service_client = BlobServiceClient(account_url=account_url, credential=sas_token)
        container_client = blob_service_client.get_container_client(container_name)

        # Dictionary to store DataFrames for each file
        dataframes = {}

        # List all blobs in the specified folder
        blob_list = container_client.list_blobs(name_starts_with=target_folder_path)

        for blob in blob_list:
            file_name = blob.name.split('/')[-1]  # Get only the file name

            # Download the blob
            blob_client = container_client.get_blob_client(blob.name)
            blob_data = blob_client.download_blob().readall()

            # Check file extension and load data accordingly
            if file_name.endswith('.xlsx') or file_name.endswith('.xls'):
                df = pd.read_excel(io.BytesIO(blob_data))  # Read Excel file
            elif file_name.endswith('.csv'):
                df = pd.read_csv(io.BytesIO(blob_data))  # Read CSV file
            else:
                continue  # Skip files that are neither Excel nor CSV

            # Store the DataFrame in the dictionary with the file name as the key
            dataframes[file_name] = df

        # Modify the input code to use the DataFrame from memory instead of reading from a file
        input1 = input1.replace("pd.read_excel(", "dataframes.get(").replace("pd.read_csv(", "dataframes.get(")

        # Capture the console print outputs
        with io.StringIO() as buf, contextlib.redirect_stdout(buf):
            # Provide the dictionary of DataFrames and required imports in the local scope of the executed code
            local_vars = {
                "dataframes": dataframes,
                "pd": pd,
                "datetime": datetime
            }

            # Execute the Python code provided as input
            exec(input1, {}, local_vars)
            output = buf.getvalue().strip()  # Remove the trailing newline character

        # Store the output or any result in input1
        input1 = output if output else "  "
        
        return input1  # Return the result as input1

    except Exception as e:
        error = str(e)  # Save the error message
        return input1  # Return nothing (as per your instruction)