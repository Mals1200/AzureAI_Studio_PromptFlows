import pandas as pd
from azure.storage.blob import BlobServiceClient
import io
import warnings
import json
from promptflow import tool
import os

# Suppress warnings
warnings.filterwarnings("ignore")
# Temorary fix of deployment
os.environ['PF_DISABLE_TRACING'] = 'true'


@tool
def retrieve_sample_data() -> str:
    account_url = "https://cxqaazureaihub8779474245.blob.core.windows.net"
    sas_token = "sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2030-11-21T02:02:26Z&st=2024-11-20T18:02:26Z&spr=https&sig=YfZEUMeqiuBiG7le2JfaaZf%2FW6t8ZW75yCsFM6nUmUw%3D"
    container_name = "5d74a98c-1fc6-4567-8545-2632b489bd0b-azureml-blobstore"

    blob_service_client = BlobServiceClient(account_url=account_url, credential=sas_token)
    container_client = blob_service_client.get_container_client(container_name)

    target_folder_path = "UI/2024-11-20_142337_UTC/cxqa_data/tabular/"

    sample_data_dict = {}

    try:
        blob_list = container_client.list_blobs(name_starts_with=target_folder_path)

        for blob in blob_list:
            if blob.name.endswith('.xlsx') or blob.name.endswith('.xls'):
                file_name = blob.name.split('/')[-1]
                blob_data = container_client.get_blob_client(blob).download_blob().readall()
                df = pd.read_excel(io.BytesIO(blob_data))

                if df.empty:
                    print(f"No data found in {file_name}")
                    continue  # Skip empty DataFrames

                # Format datetime columns
                for col in df.select_dtypes(include=['datetime64']).columns:
                    df[col] = df[col].dt.strftime('%d-%B-%Y')

                sample_data = df.head(3)

                # Build the formatted output string
                formatted_samples = []
                for index, row in sample_data.iterrows():
                    formatted_row = ', '.join([f"{col}: {value}" for col, value in row.items()])
                    formatted_samples.append(f"- {index + 1} {formatted_row}")

                sample_data_dict[file_name] = f"{file_name} has the following sample rows:\n" + "\n".join(formatted_samples)

        # Build the final output string
        output = '\n\n'.join([f"{i + 1}) {desc}" for i, desc in enumerate(sample_data_dict.values())])

    except Exception as e:
        output = json.dumps({"error": str(e)})

    return output  # Ensure to return the final output
